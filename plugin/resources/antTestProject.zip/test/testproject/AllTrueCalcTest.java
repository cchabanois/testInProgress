package testproject;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AllTrueCalcTest {

	
	@Test
	public void test1Plus1() {
		assertEquals(2, new Calc().add(1, 1));
	}	
	
	@Test
	public void test1Plus2() {
		assertEquals(3, new Calc().add(1, 2));
	}	

	@Test
	public void test2Plus2() {
		assertEquals(4, new Calc().add(2, 2));
	}	

	@Test
	public void test3Plus2() {
		assertEquals(5, new Calc().add(3, 2));
	}	

	@Test
	public void test4Plus2() {
		assertEquals(6, new Calc().add(4, 2));
	}	

	@Test
	public void test5Plus2() {
		assertEquals(7, new Calc().add(5, 2));
	}	

	@Test
	public void test3Plus1() {
		assertEquals(4, new Calc().add(3, 1));
	}	
	
	@Test
	public void test4Plus3() {
		assertEquals(7, new Calc().add(4, 3));
	}	

	@Test
	public void test5Plus3() {
		assertEquals(8, new Calc().add(5, 3));
	}	

	@Test
	public void test6Plus2() {
		assertEquals(8, new Calc().add(6, 2));
	}	

	@Test
	public void test7Plus2() {
		assertEquals(9, new Calc().add(7, 2));
	}	

	@Test
	public void test8Plus2() {
		assertEquals(10, new Calc().add(8, 2));
	}	
	
}
