package testproject;

import org.junit.Test;

public class DelayTest {

	@Test
	public void testSleep() throws InterruptedException {
		Thread.sleep(5000);
	}
	
}
