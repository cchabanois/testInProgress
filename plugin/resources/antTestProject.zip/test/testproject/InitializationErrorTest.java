package testproject;

import org.junit.Test;

public class InitializationErrorTest {

	
	@Test
	public void testException(int input) {


	}	
	
}
