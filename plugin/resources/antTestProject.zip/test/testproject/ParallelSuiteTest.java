package testproject;

import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(org.kohsuke.junit4.ParallelSuite.class)
@SuiteClasses({ ParameterizedTest.class,
		ParameterizedTest2.class })
public class ParallelSuiteTest {

}
