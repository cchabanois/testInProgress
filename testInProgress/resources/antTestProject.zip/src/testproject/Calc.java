package testproject;

import org.junit.runner.JUnitCore;

public class Calc {

	public long add(int a, int b) {
		return a + b;
	}

}
