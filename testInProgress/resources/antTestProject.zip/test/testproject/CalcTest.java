package testproject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Ignore;
import org.junit.Test;

import testproject.Calc;

public class CalcTest {
	
	@Test
	public void testAddWillSucceed() {
		assertEquals(5, new Calc().add(2, 3));
	}
	
	@Test
	public void testAddWillFail() {
		assertEquals(6, new Calc().add(2, 3));
	}	

	@Test
	@Ignore
	public void testIgnored() {
	}
	
	@Test
	public void testFail() {
		fail("this test failed");
	}
	
	public static void main(String[] args) {
//	    JUnitCore core= new JUnitCore();
//	    core.addListener(new MyRunListener());
//	    core.run(CalcTest.class, CalcTest2.class);
	    
//	    TestRunner runner = new TestRunner();
//	    junit.framework.Test calcTest = new JUnit4TestAdapter(CalcTest.class);
//	    junit.framework.Test calcTest2 = new JUnit4TestAdapter(CalcTest2.class);
//	    TestSuite testSuite = new TestSuite();
//	    testSuite.addTestSuite(calcTest);
//	    testSuite.addTest(calcTest2);
//	    TestResult testResult = new TestResult();
//	    testResult.addListener(new JUnitProgressResultFormatter());
//	    testSuite.run(testResult);
	}	
}
