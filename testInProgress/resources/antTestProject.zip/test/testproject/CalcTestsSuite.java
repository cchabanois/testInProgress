package testproject;

import org.junit.runner.JUnitCore;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CalcTest.class, CalcTest2.class })
public class CalcTestsSuite {

	public static void main(String[] args) {
		JUnitCore core= new JUnitCore();
//		core.addListener(new JUnit4TestListener());
		core.run(CalcTestsSuite.class);
	}

}
