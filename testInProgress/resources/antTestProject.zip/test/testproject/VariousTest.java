package testproject;

import org.junit.Test;

public class VariousTest {

	@Test(timeout = 500)
	public void testTimeout() {
		while (1 == 1) {

		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void testException(int input) {
		System.out
				.println("@Test(expected) will check for specified exception during its run");

	}

}
